<?php
class itHidden {	
	function one_half( $atts = null, $content = null ) {
		return '<div class="one_half">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function one_half_last( $atts = null, $content = null ) {
		return '<div class="one_half last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function one_third( $atts = null, $content = null ) {
		return '<div class="one_third">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function one_third_last( $atts = null, $content = null ) {
		return '<div class="one_third last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function two_third( $atts = null, $content = null ) {
		return '<div class="two_third">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function two_third_last( $atts = null, $content = null ) {
		return '<div class="two_third last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function one_fourth( $atts = null, $content = null ) {
		return '<div class="one_fourth">' . it_cleanup_shortcode( $content ) . '</div>';
	}	
	function one_fourth_last( $atts = null, $content = null ) {
		return '<div class="one_fourth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function three_fourth( $atts = null, $content = null ) {
		return '<div class="three_fourth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function three_fourth_last( $atts = null, $content = null ) {
		return '<div class="three_fourth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function one_fifth( $atts = null, $content = null ) {
		return '<div class="one_fifth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function one_fifth_last( $atts = null, $content = null ) {
		return '<div class="one_fifth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function two_fifth( $atts = null, $content = null ) {
		return '<div class="two_fifth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function two_fifth_last( $atts = null, $content = null ) {
		return '<div class="two_fifth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function three_fifth( $atts = null, $content = null ) {
		return '<div class="three_fifth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function three_fifth_last( $atts = null, $content = null ) {
		return '<div class="three_fifth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function four_fifth( $atts = null, $content = null ) {
		return '<div class="four_fifth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function four_fifth_last( $atts = null, $content = null ) {
		return '<div class="four_fifth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function one_sixth( $atts = null, $content = null ) {
		return '<div class="one_sixth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function one_sixth_last( $atts = null, $content = null ) {
		return '<div class="one_sixth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
	function five_sixth( $atts = null, $content = null ) {		
		return '<div class="five_sixth">' . it_cleanup_shortcode( $content ) . '</div>';
	}
	function five_sixth_last( $atts = null, $content = null ) {
		return '<div class="five_sixth last">' . it_cleanup_shortcode( $content ) . '</div><div class="clearboth"></div>';
	}
}
?>
