<?php get_header(); # show header

#get theme option
$builder = it_get_setting('builder_page');
#get specific page meta
$builder_meta = get_post_meta($post->ID, '_builder', $single = true);
$builder_meta = unserialize($builder_meta) ? unserialize($builder_meta) : '';
if(!empty($builder_meta) && $builder_meta!='') $builder = $builder_meta;

#loop through content panels
if(!empty($builder)) {
	foreach($builder as $component) {
		it_get_template_part($component);	
	}
} else {
	it_get_template_part('page-content');
} 

get_footer(); # show footer ?>