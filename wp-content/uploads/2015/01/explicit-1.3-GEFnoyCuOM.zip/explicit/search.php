<?php get_header(); # show header ?>

<?php 
#loop through content panels
$builder = it_get_setting('builder_search');
if(!empty($builder)) {
	foreach($builder as $component) {
		if($component!='page-content') it_get_template_part($component);	
	}
} else {
	it_get_template_part('list-paged');
} 
?>

<?php get_footer(); # show footer ?>