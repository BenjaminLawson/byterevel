<?php
#Template Name: Author Listing
?>
<?php get_header(); # show header ?>

<?php 
#loop through content panels
$builder = it_get_setting('builder_author');
if(!empty($builder)) {
	foreach($builder as $component) {
		it_get_template_part($component);	
	}
} else {
	it_get_template_part('page-content');
} 
?>

<?php get_footer(); # show footer ?>